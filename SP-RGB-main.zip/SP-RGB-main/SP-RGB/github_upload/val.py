from __future__ import annotations

import argparse
import os
import tempfile
from pathlib import Path


def _find_latest_weight(search_roots: list[Path], prefer: str = "best.pt") -> Path | None:
    candidates: list[Path] = []
    for root in search_roots:
        if not root.exists():
            continue
        candidates.extend([p for p in root.rglob(prefer) if p.is_file()])
    if not candidates:
        return None
    candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0]


def _infer_dataset_root(images_dir: Path) -> Path | None:
    for parent in images_dir.parents:
        if parent.name in ("images", "image"):
            return parent.parent
    return None


def _temp_data_yaml_from_dirs(
    val_images: Path,
    test_images: Path | None,
    nc: int,
    names: list[str],
    mm_sp_dir: Path | None,
) -> str:
    root = _infer_dataset_root(val_images)
    if root is not None:
        train_rel = "images/train"
        val_rel = "images/val"
        test_rel = "images/test"
        if val_images.name != "val":
            val_rel = f"images/{val_images.name}"
        if test_images is not None and test_images.is_absolute() and root in test_images.parents:
            try:
                test_rel = str(test_images.relative_to(root)).replace("\\", "/")
            except Exception:
                test_rel = str(test_images).replace("\\", "/")
        elif test_images is not None:
            test_rel = str(test_images).replace("\\", "/")

        lines = [
            f"path: {root.as_posix()}",
            f"train: {train_rel}",
            f"val: {val_rel}",
            f"test: {test_rel}" if test_images is not None else "",
        ]
    else:
        lines = [
            f"train: {val_images.as_posix()}",
            f"val: {val_images.as_posix()}",
            f"test: {test_images.as_posix()}" if test_images is not None else "",
        ]

    lines += [
        f"nc: {int(nc)}",
        "names:",
        *[f"  {i}: {n}" for i, n in enumerate(names)],
    ]
    if mm_sp_dir is not None:
        lines.append(f"mm_sp_dir: {mm_sp_dir.as_posix()}")

    content = "\n".join([x for x in lines if x.strip() != ""]) + "\n"
    f = tempfile.NamedTemporaryFile("w", suffix=".yaml", delete=False, encoding="utf-8")
    try:
        f.write(content)
        f.flush()
    finally:
        f.close()
    return f.name


def _temp_data_yaml_from_file(data_yaml: Path, mm_sp_dir: Path | None) -> str:
    if mm_sp_dir is None:
        return str(data_yaml)
    from ultralytics.utils import yaml_load, yaml_save

    d = yaml_load(str(data_yaml))
    d = d if isinstance(d, dict) else {}
    d["mm_sp_dir"] = str(mm_sp_dir)
    out = Path(tempfile.NamedTemporaryFile("w", suffix=".yaml", delete=False, encoding="utf-8").name)
    yaml_save(out, d)
    return str(out)


def _print_metrics(metrics):
    box = getattr(metrics, "box", None)
    speed = getattr(metrics, "speed", None) or getattr(box, "speed", None)

    mp = float(getattr(box, "mp", 0.0))
    mr = float(getattr(box, "mr", 0.0))
    map50 = float(getattr(box, "map50", 0.0))
    map5095 = float(getattr(box, "map", 0.0))

    print(f"Precision  : {mp}")
    print(f"Recall     : {mr}")
    print(f"mAP50      : {map50}")
    print(f"mAP50-95   : {map5095}")

    all_ap = getattr(box, "all_ap", None)
    if all_ap is not None:
        try:
            import numpy as np

            a = np.asarray(all_ap)
            if a.ndim == 2 and a.shape[1] == 10:
                mean_per_iou = a.mean(0)
                thresholds = [50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
                for t, v in zip(thresholds, mean_per_iou.tolist()):
                    print(f"mAP{t}     : {float(v)}")
        except Exception:
            pass

    if isinstance(speed, dict):
        try:
            total_ms = float(speed.get("preprocess", 0.0)) + float(speed.get("inference", 0.0)) + float(speed.get("postprocess", 0.0))
            if total_ms > 0:
                fps = 1000.0 / total_ms
                print(f"FPS        : {fps}")
        except Exception:
            pass


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--weights", type=str, default=os.getenv("WEIGHTS", ""))
    p.add_argument("--data", type=str, default=os.getenv("DATA_YAML", ""))
    p.add_argument("--val-images", type=str, default=os.getenv("VAL_IMAGES", ""))
    p.add_argument("--test-images", type=str, default=os.getenv("TEST_IMAGES", ""))
    p.add_argument("--mm-sp-dir", type=str, default=os.getenv("MM_SP_DIR", ""))
    p.add_argument("--imgsz", type=int, default=int(os.getenv("IMGSZ", "1280")))
    p.add_argument("--batch", type=int, default=int(os.getenv("BATCH", "1")))
    p.add_argument("--device", type=str, default=os.getenv("DEVICE", "0"))
    p.add_argument("--conf", type=float, default=float(os.getenv("CONF", "0.001")))
    p.add_argument("--iou", type=float, default=float(os.getenv("IOU", "0.7")))
    p.add_argument("--nc", type=int, default=int(os.getenv("NC", "1")))
    p.add_argument("--names", type=str, default=os.getenv("NAMES", "person"))
    args = p.parse_args()

    from patch_ultralytics import apply_ultralytics_patches

    apply_ultralytics_patches()

    from ultralytics import YOLO

    weights = Path(args.weights) if args.weights else None
    if weights is None or not weights.exists():
        here = Path(__file__).resolve()
        local_best = here.parent / "weights" / "best.pt"
        if local_best.exists():
            weights = local_best
        else:
            latest = _find_latest_weight(
                [
                    here.parents[1] / "runs" / "detect",
                    here.parents[1] / "runs_debug",
                ],
                prefer="best.pt",
            )
            if latest is None:
                raise FileNotFoundError("weights not found; pass --weights or set WEIGHTS")
            weights = latest

    mm_sp_dir = Path(args.mm_sp_dir) if args.mm_sp_dir else None
    if mm_sp_dir is not None and not mm_sp_dir.exists():
        raise FileNotFoundError(f"MM_SP_DIR not found: {mm_sp_dir}")

    data_yaml = None
    if args.data:
        data_yaml = Path(args.data)
        if not data_yaml.exists():
            raise FileNotFoundError(f"DATA_YAML not found: {data_yaml}")
        data_path = _temp_data_yaml_from_file(data_yaml, mm_sp_dir)
    else:
        if not args.val_images:
            raise FileNotFoundError("pass --data/--val-images or set DATA_YAML/VAL_IMAGES")
        val_images = Path(args.val_images)
        if not val_images.exists():
            raise FileNotFoundError(f"VAL_IMAGES not found: {val_images}")
        test_images = Path(args.test_images) if args.test_images else None
        if test_images is not None and not test_images.exists():
            raise FileNotFoundError(f"TEST_IMAGES not found: {test_images}")
        names = [x.strip() for x in args.names.split(",") if x.strip()]
        data_path = _temp_data_yaml_from_dirs(val_images, test_images, args.nc, names, mm_sp_dir)

    model = YOLO(str(weights))
    metrics = model.val(
        data=data_path,
        imgsz=int(args.imgsz),
        batch=int(args.batch),
        device=args.device,
        conf=float(args.conf),
        iou=float(args.iou),
    )
    _print_metrics(metrics)


if __name__ == "__main__":
    main()
