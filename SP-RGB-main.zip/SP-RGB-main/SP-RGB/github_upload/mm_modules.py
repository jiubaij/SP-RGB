from __future__ import annotations

import os
from copy import deepcopy
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F

from ultralytics.nn.modules.conv import Conv
from ultralytics.utils.plotting import feature_visualization


class IN(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        return x


class ChannelSelect(nn.Module):
    def __init__(self, start: int, end: int):
        super().__init__()
        self.start = int(start)
        self.end = int(end)

    def forward(self, x):
        return x[:, self.start:self.end, :, :]


class AlignWarp(nn.Module):
    def __init__(
        self,
        c_sp: int,
        c_opt: int,
        hidden: int = 16,
        max_shift: float = 25.0,
        visualize_freq: int = 50,
        save_dir: str = "./visualizations",
        reg_weight: float = 0.01,
        curriculum_epochs: int = 10,
        curriculum_max_shift: float = 15.0,
        align_loss_weight: float = 5000.0,
    ):
        super().__init__()
        self.c_sp = int(c_sp)
        self.c_opt = int(c_opt)
        self.hidden = int(hidden)

        self.max_shift = float(max_shift)
        self.visualize_freq = int(visualize_freq)
        self.save_dir = str(save_dir) if isinstance(save_dir, str) else "./visualizations"
        self.reg_weight = float(reg_weight)
        self.align_loss_weight = float(align_loss_weight)
        self.curriculum_epochs = int(curriculum_epochs)
        self.curriculum_max_shift = float(curriculum_max_shift)

        try:
            os.makedirs(self.save_dir, exist_ok=True)
        except Exception:
            pass

        self.target_guesser = nn.Sequential(
            Conv(self.c_opt, self.hidden, k=3, s=1),
            nn.Conv2d(self.hidden, 1, kernel_size=1),
            nn.Sigmoid(),
        )
        self.local_off = nn.Sequential(
            Conv(self.c_sp + self.c_opt, self.hidden, k=3, s=1),
            nn.Conv2d(self.hidden, self.hidden, kernel_size=3, padding=2, dilation=2, bias=False),
            nn.BatchNorm2d(self.hidden),
            nn.SiLU(inplace=True),
            nn.Conv2d(self.hidden, self.hidden, kernel_size=3, padding=4, dilation=4, bias=False),
            nn.BatchNorm2d(self.hidden),
            nn.SiLU(inplace=True),
        )
        self.global_off = nn.Sequential(
            nn.AdaptiveAvgPool2d(4),
            nn.Conv2d(self.c_sp + self.c_opt, self.hidden, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(self.hidden, self.hidden, 1),
        )
        self.offnet_final = nn.Conv2d(self.hidden, 2, kernel_size=1)
        nn.init.constant_(self.offnet_final.weight, 0)
        nn.init.constant_(self.offnet_final.bias, 0)

        self._grid_cache: dict[tuple, torch.Tensor] = {}
        self._meta: dict = {}
        self.aux_loss_container = []
        self.l1_loss = nn.L1Loss()

        try:
            def gaussian_kernel(size: int, sigma: float):
                coords = torch.arange(size) - (size - 1) / 2.0
                g = torch.exp(-(coords ** 2) / (2.0 * sigma ** 2))
                g = g / g.sum()
                return g.view(1, -1) * g.view(-1, 1)

            g = gaussian_kernel(7, 2.0)
            self.register_buffer("gaussian_ext", g.view(1, 1, 7, 7), persistent=False)
        except Exception:
            self.gaussian_ext = None

    def set_meta(self, **kwargs):
        self._meta.update(kwargs)
        return self

    def __deepcopy__(self, memo):
        cls = self.__class__
        result = cls.__new__(cls)
        memo[id(self)] = result
        for k, v in self.__dict__.items():
            if k in ("aux_loss_container", "_grid_cache", "_meta"):
                setattr(result, k, [] if k == "aux_loss_container" else {})
            else:
                try:
                    setattr(result, k, deepcopy(v, memo))
                except Exception:
                    setattr(result, k, v)
        return result

    def __getstate__(self):
        state = self.__dict__.copy()
        state["_grid_cache"] = {}
        state["_meta"] = {}
        state["aux_loss_container"] = []
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)
        if "_grid_cache" not in self.__dict__:
            self._grid_cache = {}
        if "_meta" not in self.__dict__:
            self._meta = {}
        if "aux_loss_container" not in self.__dict__:
            self.aux_loss_container = []
        if "align_loss_weight" not in self.__dict__:
            self.align_loss_weight = 5000.0

    def _base_grid(self, B: int, H: int, W: int, device, dtype):
        key = (H, W, str(device), str(dtype))
        if key in self._grid_cache:
            g = self._grid_cache[key]
            if g.device == device and g.dtype == dtype:
                return g
        ys = torch.linspace(-1, 1, H, device=device, dtype=dtype)
        xs = torch.linspace(-1, 1, W, device=device, dtype=dtype)
        grid_y, grid_x = torch.meshgrid(ys, xs, indexing="ij")
        grid = torch.stack([grid_x, grid_y], dim=-1).unsqueeze(0)
        self._grid_cache[key] = grid
        return grid

    def forward(self, x, **kwargs):
        F_sp, F_opt = x
        B, _, H_opt, W_opt = F_opt.shape
        if F_sp.shape[2] != H_opt or F_sp.shape[3] != W_opt:
            F_sp = F.interpolate(F_sp, size=(H_opt, W_opt), mode="bilinear", align_corners=True)
        H, W = H_opt, W_opt

        epoch = self._meta.get("epoch", None)
        sp_labels = self._meta.get("sp_labels", None)
        opt_labels = self._meta.get("opt_labels", None)
        dtype = next(self.offnet_final.parameters()).dtype
        F_sp = F_sp.to(dtype)
        F_opt = F_opt.to(dtype)

        sp_bboxes = None
        sp_batch_idx = None
        if isinstance(sp_labels, dict):
            sp_bboxes = sp_labels.get("bboxes", None)
            sp_batch_idx = sp_labels.get("batch_idx", None)
        opt_bboxes = None
        opt_batch_idx = None
        if isinstance(opt_labels, dict):
            opt_bboxes = opt_labels.get("bboxes", None)
            opt_batch_idx = opt_labels.get("batch_idx", None)

        if self.gaussian_ext is not None:
            Csp = F_sp.shape[1]
            kernel = self.gaussian_ext.to(device=F_sp.device, dtype=F_sp.dtype).repeat(Csp, 1, 1, 1)
            F_sp_enhanced = F.conv2d(F_sp, kernel, padding=3, groups=Csp)
        else:
            F_sp_enhanced = F_sp.clone()

        local_mean = F.avg_pool2d(F_sp_enhanced, kernel_size=3, stride=1, padding=1)
        F_sp_peaks = F.relu(F_sp_enhanced - local_mean)

        F_opt_detached = F_opt.detach()
        target_map = self.target_guesser(F_opt_detached)
        fused_input = torch.cat([F_sp_peaks, F_opt_detached * (1 + target_map)], dim=1)
        l_off = self.local_off(fused_input)
        g_off = self.global_off(fused_input)
        g_off = F.interpolate(g_off, size=(l_off.shape[2], l_off.shape[3]), mode="bilinear", align_corners=True)
        flow = self.offnet_final(l_off + g_off)
        flow = flow * (1 + target_map)
        if flow.shape[2] != H or flow.shape[3] != W:
            flow = F.interpolate(flow, size=(H, W), mode="bilinear", align_corners=True)
        self.flow = flow

        flow_norm = torch.tanh(flow) * self.max_shift
        flow_norm_scaled = torch.zeros_like(flow_norm)
        flow_norm_scaled[:, 0, :, :] = flow_norm[:, 0, :, :] / (W / 2.0)
        flow_norm_scaled[:, 1, :, :] = flow_norm[:, 1, :, :] / (H / 2.0)
        flow_norm_scaled = torch.nan_to_num(flow_norm_scaled, nan=0.0, posinf=0.0, neginf=0.0)
        flow_norm_scaled = flow_norm_scaled.permute(0, 2, 3, 1)

        base = self._base_grid(B, H, W, F_sp.device, F_sp.dtype)
        grid = base - flow_norm_scaled

        F_sp_aligned = F.grid_sample(F_sp, grid, mode="bilinear", padding_mode="border", align_corners=True)

        alignment_loss = torch.tensor(0.0, device=F_sp.device, dtype=dtype)
        has_valid_labels = (
            sp_bboxes is not None
            and opt_bboxes is not None
            and isinstance(sp_bboxes, torch.Tensor)
            and isinstance(sp_batch_idx, torch.Tensor)
            and isinstance(opt_bboxes, torch.Tensor)
            and isinstance(opt_batch_idx, torch.Tensor)
            and sp_bboxes.numel() > 0
            and sp_batch_idx.numel() > 0
            and opt_bboxes.numel() > 0
            and opt_batch_idx.numel() > 0
        )

        computed_valid = False
        if has_valid_labels:
            try:
                img_size = 1280.0
                pred_offsets_px = []
                target_offsets_px = []
                for bi in range(B):
                    sel_sp = sp_batch_idx == bi
                    sel_opt = opt_batch_idx == bi
                    if sel_sp.any() and sel_opt.any():
                        sp_pts = sp_bboxes[sel_sp][:, 0:2].to(dtype=dtype)
                        opt_pts = opt_bboxes[sel_opt][:, 0:2].to(dtype=dtype)
                        for sp_xy in sp_pts:
                            dists = torch.norm(sp_xy - opt_pts, dim=1)
                            min_idx = torch.argmin(dists)
                            best_opt_xy = opt_pts[min_idx]
                            ix = torch.clamp((best_opt_xy[0] * (W - 1)).round().long(), 0, W - 1)
                            iy = torch.clamp((best_opt_xy[1] * (H - 1)).round().long(), 0, H - 1)
                            p_off_px = torch.tanh(flow[bi, :, iy, ix]) * self.max_shift
                            t_off_px = (best_opt_xy - sp_xy) * img_size
                            pred_offsets_px.append(p_off_px)
                            target_offsets_px.append(t_off_px)

                if pred_offsets_px:
                    pred_t = torch.stack(pred_offsets_px)
                    target_t = torch.stack(target_offsets_px)
                    raw_l1 = F.l1_loss(pred_t, target_t)
                    alignment_loss = torch.tanh(raw_l1 / 10.0) * 2.0
                    computed_valid = True
            except Exception:
                alignment_loss = torch.tensor(0.0, device=F_sp.device, dtype=dtype)

        epoch_weight = self.align_loss_weight
        if epoch is not None and isinstance(epoch, int):
            if epoch < 30:
                epoch_weight = self.align_loss_weight * 1.0
            elif epoch < 100:
                decay = 1.0 - (epoch - 30) / 70.0 * 0.9
                epoch_weight = self.align_loss_weight * decay
            else:
                epoch_weight = self.align_loss_weight * 0.1

        weighted_alignment_loss = alignment_loss * epoch_weight
        loss_to_store = None
        if self.training and self.align_loss_weight > 0.0 and epoch_weight > 0.0:
            loss_to_store = weighted_alignment_loss if computed_valid else torch.tensor(0.0, device=F_sp.device, dtype=dtype)
        if isinstance(loss_to_store, torch.Tensor) and (not self.training):
            loss_to_store = loss_to_store.detach()
        self.aux_loss_container = [loss_to_store] if isinstance(loss_to_store, torch.Tensor) else []

        return F_sp_aligned


class CMGA_Guidance(nn.Module):
    def __init__(
        self,
        c_sp: int,
        c_opt: int,
        hidden: int = 32,
        temp: float = 2.0,
        stop_gradient: bool = False,
        beta_init: float = 1.0,
        alignment_threshold: float = 0.05,
        strict_guidance: bool = False,
    ):
        super().__init__()
        self.temp = float(temp)
        self.stop_gradient = bool(stop_gradient)
        self.alignment_threshold = float(alignment_threshold)
        self.strict_guidance = bool(strict_guidance)

        self.sp_spatial = nn.Sequential(
            Conv(int(c_sp), int(hidden), k=3, s=1),
            Conv(int(hidden), 1, k=1, s=1, act=False),
        )
        self.sp_gate = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(int(c_sp), int(hidden), 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(int(hidden), 1, 1),
            nn.Sigmoid(),
        )
        self.sp_proj = Conv(int(c_sp), int(c_opt), k=1, s=1)
        self.beta = nn.Parameter(torch.tensor(0.0))
        self.peak_enhancer = Conv(int(c_sp), int(c_sp), k=3, s=1, g=int(c_sp))
        self._meta: dict = {}

    def set_meta(self, **kwargs):
        self._meta.update(kwargs)
        return self

    def __setstate__(self, state):
        self.__dict__.update(state)
        if "peak_enhancer" not in self.__dict__:
            self.peak_enhancer = nn.Identity()
        if "_meta" not in self.__dict__:
            self._meta = {}

    def forward(self, x, **kwargs):
        if isinstance(x, (list, tuple)):
            F_sp, F_opt = x
        else:
            F_sp, F_opt = x, x

        dtype = next(self.sp_proj.parameters()).dtype
        F_sp = F_sp.to(dtype)
        F_opt = F_opt.to(dtype)

        F_sp_p = self.peak_enhancer(F_sp)
        sa = self.sp_spatial(F_sp_p.detach() if self.stop_gradient else F_sp_p)
        sa = torch.sigmoid(sa / float(self.temp))

        gate = self.sp_gate(F_sp_p.detach() if self.stop_gradient else F_sp_p)
        F_sp_proj = self.sp_proj(F_sp_p.detach() if self.stop_gradient else F_sp_p)

        beta = torch.sigmoid(self.beta) * 2.0
        output = F_opt * (1 + beta * sa) + beta * 0.2 * gate * F_sp_proj
        return output


class SSENhance(nn.Module):
    def __init__(self, c_sp: int, c_opt: int, hidden: int = 32, reduction: int = 16):
        super().__init__()
        self.sp_align = Conv(int(c_sp), int(c_opt), k=1, s=1) if int(c_sp) != int(c_opt) else nn.Identity()
        self.sp_enhancer = nn.Sequential(
            Conv(int(c_opt), int(c_opt), k=3, s=1),
            Conv(int(c_opt), int(c_opt), k=3, s=1),
        )
        self.opt_enhancer = nn.Sequential(
            Conv(int(c_opt), int(c_opt), k=3, s=1),
            Conv(int(c_opt), int(c_opt), k=3, s=1),
        )

        red = max(int(c_opt) // int(reduction), 1)
        self.sp_to_opt_channel_attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(int(c_opt), red, kernel_size=1, stride=1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(red, int(c_opt), kernel_size=1, stride=1, padding=0),
            nn.Sigmoid(),
        )
        self.opt_to_sp_channel_attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(int(c_opt), red, kernel_size=1, stride=1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(red, int(c_opt), kernel_size=1, stride=1, padding=0),
            nn.Sigmoid(),
        )
        self.joint_spatial_attn = nn.Sequential(
            nn.Conv2d(int(c_opt) * 2, int(c_opt), kernel_size=1, stride=1, padding=0),
            nn.Sigmoid(),
        )
        self.fusion_conv = Conv(int(c_opt) * 2, int(c_opt), k=1, s=1)
        self.fusion_weight = nn.Parameter(torch.tensor(0.0))

    def forward(self, x, **kwargs):
        if not isinstance(x, (list, tuple)) or len(x) != 2:
            raise TypeError(f"SSENhance expected [F_sp, F_opt], got {type(x)}")
        F_sp, F_opt = x

        dtype = next(self.fusion_conv.parameters()).dtype
        F_sp = F_sp.to(dtype)
        F_opt = F_opt.to(dtype)

        F_sp_aligned = self.sp_align(F_sp)
        F_sp_enhanced = self.sp_enhancer(F_sp_aligned)
        F_opt_enhanced = self.opt_enhancer(F_opt)

        sp_ca = self.sp_to_opt_channel_attn(F_sp_enhanced)
        opt_ca = self.opt_to_sp_channel_attn(F_opt_enhanced)
        F_opt_attended = F_opt_enhanced * sp_ca
        F_sp_attended = F_sp_enhanced * opt_ca

        spatial_attn = self.joint_spatial_attn(torch.cat([F_opt_attended, F_sp_attended], dim=1))
        F_opt_spatial = F_opt_attended * spatial_attn
        F_sp_spatial = F_sp_attended * spatial_attn

        fused = torch.cat([F_opt_spatial, F_sp_spatial], dim=1)
        fused_output = self.fusion_conv(fused)
        fusion_weight = torch.sigmoid(self.fusion_weight)
        output = F_opt_enhanced + fusion_weight * fused_output

        return output
