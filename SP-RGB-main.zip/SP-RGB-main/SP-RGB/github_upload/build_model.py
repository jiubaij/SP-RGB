import os
import sys


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, here)

    from patch_ultralytics import apply_ultralytics_patches
    apply_ultralytics_patches()

    from ultralytics import YOLO
    model = YOLO(os.path.join(here, "models", "spatial_spectral_enhance.yaml"))
    model.info()
    print("BUILD_OK")


if __name__ == "__main__":
    main()
