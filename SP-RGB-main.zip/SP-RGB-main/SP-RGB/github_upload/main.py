import argparse
import os

def main():
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

    import torch

    from patch_ultralytics import apply_ultralytics_patches

    apply_ultralytics_patches()

    from ultralytics import YOLO

    here = os.path.dirname(os.path.abspath(__file__))

    torch.use_deterministic_algorithms(False)

    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, default=None, help="Path to Ultralytics dataset YAML")
    parser.add_argument(
        "--model",
        type=str,
        default=os.path.join("models", "spatial_spectral_enhance.yaml"),
        help="Path to model YAML (relative to github_upload/ or absolute)",
    )
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch", type=int, default=2)
    parser.add_argument("--imgsz", type=int, default=1280)
    parser.add_argument("--device", type=str, default="0")
    parser.add_argument("--resume", action="store_true", default=False)
    parser.add_argument("--project", type=str, default=os.path.join("runs", "detect"))
    parser.add_argument("--name", type=str, default="scratch_ch4_align_cmga")
    parser.add_argument("--ch", type=int, default=4)
    args = parser.parse_args()

    model_yaml = args.model
    if not os.path.isabs(model_yaml):
        model_yaml = os.path.join(here, model_yaml)
    if not os.path.exists(model_yaml):
        raise FileNotFoundError(f"Model yaml not found: {model_yaml}")
    model = YOLO(model_yaml)

    data_yaml = args.data or os.environ.get("DATA_YAML")
    if not data_yaml:
        candidates = [
            os.path.join(here, "mydata.yaml"),
            os.path.normpath(os.path.join(here, "..", "ultralytics", "cfg", "datasets", "mydata.yaml")),
        ]
        for c in candidates:
            if os.path.exists(c):
                data_yaml = c
                break
    if not data_yaml or not os.path.exists(data_yaml):
        raise FileNotFoundError("Dataset yaml not found. Set DATA_YAML env var or provide mydata.yaml in github_upload/.")

    model.train(
        data=data_yaml,
        epochs=args.epochs,
        batch=args.batch,
        imgsz=args.imgsz,
        device=args.device,
        resume=args.resume,
        project=args.project,
        name=args.name,
        exist_ok=True,
        ch=args.ch,
        lr0=0.005,
        weight_decay=0.001,
        warmup_epochs=5,
        lrf=0.05,
        mixup=0.0,
        translate=0.05,
        scale=0.2,
        hsv_h=0.0,
        hsv_s=0.0,
        hsv_v=0.0,
        close_mosaic=12,
    )


if __name__ == "__main__":
    main()
