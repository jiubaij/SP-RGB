from __future__ import annotations

import contextlib


def apply_ultralytics_patches():
    from ultralytics.nn import tasks as tasks_mod

    from mm_modules import AlignWarp, ChannelSelect, CMGA_Guidance, IN, SSENhance

    tasks_mod.IN = IN
    tasks_mod.ChannelSelect = ChannelSelect
    tasks_mod.AlignWarp = AlignWarp
    tasks_mod.CMGA_Guidance = CMGA_Guidance
    tasks_mod.SSENhance = SSENhance

    with contextlib.suppress(Exception):
        from ultralytics.nn import modules as modules_mod

        modules_mod.IN = IN
        modules_mod.ChannelSelect = ChannelSelect
        modules_mod.AlignWarp = AlignWarp
        modules_mod.CMGA_Guidance = CMGA_Guidance
        modules_mod.SSENhance = SSENhance

    tasks_mod.parse_model = _parse_model_patched
    _patch_multichannel_dataloader()
    _patch_aux_losses_into_criterion()


def _parse_model_patched(d, ch, verbose=True):
    import ast
    import contextlib

    import torch
    import torch.nn as nn

    from ultralytics.utils import LOGGER, colorstr
    from ultralytics.utils.torch_utils import make_divisible

    Conv = _g("Conv")
    Concat = _g("Concat")
    Detect = _g("Detect")
    Segment = _g("Segment")
    Pose = _g("Pose")
    OBB = _g("OBB")
    Classify = _g("Classify")
    ConvTranspose = _g("ConvTranspose")
    GhostConv = _g("GhostConv")
    Bottleneck = _g("Bottleneck")
    GhostBottleneck = _g("GhostBottleneck")
    SPP = _g("SPP")
    SPPF = _g("SPPF")
    DWConv = _g("DWConv")
    Focus = _g("Focus")
    BottleneckCSP = _g("BottleneckCSP")
    C1 = _g("C1")
    C2 = _g("C2")
    C2f = _g("C2f")
    C3 = _g("C3")
    C3TR = _g("C3TR")
    C3Ghost = _g("C3Ghost")
    DWConvTranspose2d = _g("DWConvTranspose2d")
    C3x = _g("C3x")
    RepC3 = _g("RepC3")
    AIFI = _g("AIFI")
    HGStem = _g("HGStem")
    HGBlock = _g("HGBlock")
    ResNetLayer = _g("ResNetLayer")
    RTDETRDecoder = _g("RTDETRDecoder")

    ChannelSelect = _g("ChannelSelect")
    AlignWarp = _g("AlignWarp")
    CMGA_Guidance = _g("CMGA_Guidance")
    SSENhance = _g("SSENhance")

    max_channels = float("inf")
    nc, act, scales = (d.get(x) for x in ("nc", "activation", "scales"))
    depth, width, kpt_shape = (d.get(x, 1.0) for x in ("depth_multiple", "width_multiple", "kpt_shape"))
    if scales:
        scale = d.get("scale")
        if not scale:
            scale = tuple(scales.keys())[0]
            LOGGER.warning(f"WARNING ⚠️ no model scale passed. Assuming scale='{scale}'.")
        depth, width, max_channels = scales[scale]

    if act:
        Conv.default_act = eval(act)
        if verbose:
            LOGGER.info(f"{colorstr('activation:')} {act}")

    if verbose:
        LOGGER.info(f"\n{'':>3}{'from':>20}{'n':>3}{'params':>10}  {'module':<45}{'arguments':<30}")

    ch = [ch]
    layers, save = [], []
    c2 = ch[-1]

    for i, (f, n, m, args) in enumerate(d["backbone"] + d["head"]):
        m = getattr(torch.nn, m[3:]) if "nn." in m else _g(m)

        for j, a in enumerate(args):
            if isinstance(a, str):
                with contextlib.suppress(ValueError, SyntaxError):
                    args[j] = locals()[a] if a in locals() else ast.literal_eval(a)

        n = n_ = max(round(n * depth), 1) if n > 1 else n

        if m is ChannelSelect:
            if not isinstance(f, int):
                raise TypeError(f"ChannelSelect expects from=int, but got from={f}")
            start, end = args
            c2 = int(end) - int(start)

        elif m is AlignWarp:
            if not (isinstance(f, list) and len(f) == 2):
                raise TypeError(f"AlignWarp expects from=[sp,rgb], but got from={f}")
            c_sp, c_opt = ch[f[0]], ch[f[1]]
            args = [c_sp, c_opt, *args]
            c2 = c_sp

        elif m is CMGA_Guidance:
            if not (isinstance(f, list) and len(f) == 2):
                raise TypeError(f"CMGA_Guidance expects from=[sp,rgb], but got from={f}")
            c_sp, c_opt = ch[f[0]], ch[f[1]]
            if len(args) >= 2 and args[0] == c_sp and args[1] == c_opt:
                args = args[2:]
            args = [c_sp, c_opt, *args]
            c2 = c_opt

        elif m is SSENhance:
            if not (isinstance(f, list) and len(f) == 2):
                raise TypeError(f"SSENhance expects from=[sp,rgb], but got from={f}")
            c_sp, c_opt = ch[f[0]], ch[f[1]]
            if len(args) >= 4 and isinstance(args[0], (int, float)) and isinstance(args[1], (int, float)):
                args = [c_sp, c_opt, *args[2:]]
            else:
                args = [c_sp, c_opt, *args]
            c2 = c_opt

        elif m in (
            Classify,
            Conv,
            ConvTranspose,
            GhostConv,
            Bottleneck,
            GhostBottleneck,
            SPP,
            SPPF,
            DWConv,
            Focus,
            BottleneckCSP,
            C1,
            C2,
            C2f,
            C3,
            C3TR,
            C3Ghost,
            nn.ConvTranspose2d,
            DWConvTranspose2d,
            C3x,
            RepC3,
        ):
            if not isinstance(f, int):
                raise TypeError(f"Module {m.__name__} expects from=int, but got from={f}")
            c1 = ch[f]
            if len(args) == 0:
                raise ValueError(f"Module {m.__name__} requires output channel (c2) argument.")
            c2_yaml = args[0]
            if c2_yaml != nc:
                c2 = make_divisible(min(c2_yaml, max_channels) * width, 8)
            else:
                c2 = c2_yaml
            args = [c1, c2, *args[1:]]
            if m in (BottleneckCSP, C1, C2, C2f, C3, C3TR, C3Ghost, C3x, RepC3):
                args.insert(2, n_)

        elif m is AIFI:
            args = [ch[f], *args]
            c2 = args[1] if len(args) > 1 else ch[f]

        elif m in (HGStem, HGBlock):
            c1, cm, c2 = ch[f], args[0], args[1]
            args = [c1, cm, c2, *args[2:]]
            if m is HGBlock:
                args.insert(4, n)
                n = 1

        elif m is ResNetLayer:
            c2 = args[1] if args[3] else args[1] * 4

        elif m is nn.BatchNorm2d:
            args = [ch[f]]
            c2 = ch[f]

        elif m is Concat:
            c2 = sum(ch[x] for x in f)

        elif m in (Detect, Segment, Pose, OBB):
            args.append([ch[x] for x in f])
            if m is Segment:
                args[2] = make_divisible(min(args[2], max_channels) * width, 8)

        elif m is RTDETRDecoder:
            args.insert(1, [ch[x] for x in f])
            c2 = ch[f[-1]] if isinstance(f, list) else ch[f]

        else:
            if isinstance(f, int):
                c2 = ch[f]
            else:
                raise TypeError(
                    f"Module {m.__name__} has from={f} (list) but parse_model has no channel rule for it."
                )

        m_ = nn.Sequential(*(m(*args) for _ in range(n))) if n > 1 else m(*args)
        t = str(m)[8:-2].replace("__main__.", "")
        m.np = sum(x.numel() for x in m_.parameters())
        m_.i, m_.f, m_.type = i, f, t

        if verbose:
            LOGGER.info(f"{i:>3}{str(f):>20}{n_:>3}{m.np:10.0f}  {t:<45}{str(args):<30}")

        save.extend(x % i for x in ([f] if isinstance(f, int) else f) if x != -1)
        layers.append(m_)

        if i == 0:
            ch = []
        ch.append(c2)

    return nn.Sequential(*layers), sorted(save)


def _g(name: str):
    from ultralytics.nn import tasks as tasks_mod

    if name in tasks_mod.__dict__:
        return tasks_mod.__dict__[name]
    raise KeyError(name)


def _patch_multichannel_dataloader():
    import inspect

    with contextlib.suppress(Exception):
        import ultralytics.data.base as base_mod

        BaseDataset = getattr(base_mod, "BaseDataset", None)
        if BaseDataset is None:
            return

        with contextlib.suppress(Exception):
            src = inspect.getsource(BaseDataset.load_image)
            if "self.hyp.ch" in src or "la_files" in src or "IMREAD_UNCHANGED" in src:
                return

        orig_load_image = BaseDataset.load_image
        orig_cache_images_to_disk = getattr(BaseDataset, "cache_images_to_disk", None)

        def load_image_patched(self, i, rect_mode=True):
            import math
            import os
            from pathlib import Path

            import cv2
            import numpy as np

            hyp = getattr(self, "hyp", None) or getattr(self, "args", None)
            expected_ch = int(getattr(hyp, "ch", 3) if hyp is not None else 3)
            if expected_ch <= 3:
                with contextlib.suppress(TypeError):
                    return orig_load_image(self, i, rect_mode=rect_mode)
                return orig_load_image(self, i, rect_mode)

            im, f = getattr(self, "ims", [None])[i], self.im_files[i]
            fn = getattr(self, "npy_files", [Path("")])[i] if hasattr(self, "npy_files") else None
            if im is None and fn is not None and hasattr(fn, "exists") and fn.exists():
                with contextlib.suppress(Exception):
                    im = np.load(fn)
                    if im.ndim != 3 or im.shape[2] != expected_ch:
                        im = None
                        with contextlib.suppress(Exception):
                            fn.unlink(missing_ok=True)

            if im is None:
                im_stacked = cv2.imread(f, cv2.IMREAD_UNCHANGED)
                if im_stacked is not None and im_stacked.ndim == 3 and im_stacked.shape[2] >= expected_ch:
                    im = im_stacked[:, :, :expected_ch]
                else:
                    im_rgb = cv2.imread(f)
                    if im_rgb is None:
                        raise FileNotFoundError(f"Image Not Found {f}")

                    sp_path = ""
                    data = getattr(self, "data", None) if hasattr(self, "data") else None
                    if isinstance(data, dict):
                        sp_root = data.get("mm_sp_dir") or data.get("sp_dir") or data.get("sp") or data.get("ir_dir")
                        if sp_root:
                            sp_root = Path(sp_root)
                            if not sp_root.is_absolute():
                                base = Path(data.get("path") or Path(data.get("yaml_file", "")).parent or ".")
                                sp_root = (base / sp_root).resolve()
                            sp_candidate = sp_root / Path(f).name
                            if sp_candidate.exists():
                                sp_path = str(sp_candidate)
                            else:
                                from ultralytics.data.utils import IMG_FORMATS

                                stem = Path(f).stem
                                for ext in IMG_FORMATS:
                                    cand = sp_root / f"{stem}.{ext}"
                                    if cand.exists():
                                        sp_path = str(cand)
                                        break

                    if not sp_path or not os.path.exists(sp_path):
                        raise FileNotFoundError(
                            f"Expected {expected_ch}-channel input, but '{f}' is not stacked and no mm_sp_dir pairing found."
                        )

                    im_sp = cv2.imread(sp_path, cv2.IMREAD_UNCHANGED)
                    if im_sp is None:
                        raise FileNotFoundError(f"SP image not found: {sp_path}")
                    if im_sp.ndim == 3 and im_sp.shape[2] == 4:
                        im_sp = im_sp[:, :, :3]
                    if im_sp.shape[:2] != im_rgb.shape[:2]:
                        im_sp = cv2.resize(im_sp, (im_rgb.shape[1], im_rgb.shape[0]), interpolation=cv2.INTER_LINEAR)

                    if expected_ch == 4:
                        if im_sp.ndim == 3:
                            im_sp = cv2.cvtColor(im_sp, cv2.COLOR_BGR2GRAY)
                        im = np.concatenate([im_rgb, im_sp[:, :, None]], axis=2)
                    else:
                        if im_sp.ndim == 2:
                            im_sp = np.repeat(im_sp[:, :, None], 3, axis=2)
                        elif im_sp.ndim == 3 and im_sp.shape[2] > 3:
                            im_sp = im_sp[:, :, :3]
                        im = np.concatenate([im_rgb, im_sp], axis=2)

                if im.dtype != np.uint8:
                    if im.dtype == np.uint16:
                        im = (im / 256).astype(np.uint8)
                    else:
                        imf = im.astype(np.float32)
                        im_min = float(np.nanmin(imf)) if imf.size else 0.0
                        im_max = float(np.nanmax(imf)) if imf.size else 0.0
                        denom = (im_max - im_min) if im_max > im_min else 1.0
                        im = np.clip((imf - im_min) * (255.0 / denom), 0.0, 255.0).astype(np.uint8)

            h0, w0 = im.shape[:2]
            imgsz = int(getattr(self, "imgsz", max(h0, w0)))
            if rect_mode:
                r = imgsz / max(h0, w0)
                if r != 1:
                    w, h = (min(math.ceil(w0 * r), imgsz), min(math.ceil(h0 * r), imgsz))
                    im = cv2.resize(im, (w, h), interpolation=cv2.INTER_LINEAR)
            elif not (h0 == w0 == imgsz):
                im = cv2.resize(im, (imgsz, imgsz), interpolation=cv2.INTER_LINEAR)

            if getattr(self, "augment", False):
                if hasattr(self, "ims") and hasattr(self, "im_hw0") and hasattr(self, "im_hw"):
                    self.ims[i], self.im_hw0[i], self.im_hw[i] = im, (h0, w0), im.shape[:2]
                if hasattr(self, "buffer") and hasattr(self, "max_buffer_length"):
                    self.buffer.append(i)
                    if len(self.buffer) >= self.max_buffer_length:
                        j = self.buffer.pop(0)
                        if hasattr(self, "ims") and hasattr(self, "im_hw0") and hasattr(self, "im_hw"):
                            self.ims[j], self.im_hw0[j], self.im_hw[j] = None, None, None

            return im, (h0, w0), im.shape[:2]

        BaseDataset.load_image = load_image_patched

        if orig_cache_images_to_disk is not None:
            def cache_images_to_disk_patched(self, i):
                from pathlib import Path

                f = self.npy_files[i] if hasattr(self, "npy_files") else Path("")
                if hasattr(f, "exists") and f.exists():
                    return
                im, _, _ = self.load_image(i)
                import numpy as np

                np.save(f.as_posix(), im, allow_pickle=False)

            BaseDataset.cache_images_to_disk = cache_images_to_disk_patched


def _patch_aux_losses_into_criterion():
    with contextlib.suppress(Exception):
        import torch
        import ultralytics.utils.loss as loss_mod

        v8DetectionLoss = getattr(loss_mod, "v8DetectionLoss", None)
        if v8DetectionLoss is None or getattr(v8DetectionLoss, "_mm_aux_patched", False):
            return

        orig_init = v8DetectionLoss.__init__
        orig_call = v8DetectionLoss.__call__

        def init_patched(self, model):
            orig_init(self, model)
            self.model = model

        def call_patched(self, preds, batch):
            loss, loss_items = orig_call(self, preds, batch)
            model = getattr(self, "model", None)
            if model is None:
                return loss, loss_items

            aux_losses = []
            for m in model.modules():
                if hasattr(m, "aux_loss_container"):
                    container = getattr(m, "aux_loss_container") or []
                    for x in container:
                        if torch.is_tensor(x):
                            aux_losses.append(x)
            if aux_losses:
                loss = loss + torch.stack(aux_losses).sum()
            return loss, loss_items

        v8DetectionLoss.__init__ = init_patched
        v8DetectionLoss.__call__ = call_patched
        v8DetectionLoss._mm_aux_patched = True
