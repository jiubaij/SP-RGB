from __future__ import annotations

import os
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F

from ultralytics.nn.modules.conv import Conv
from ultralytics.utils.plotting import feature_visualization


class IN(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        return x


class ChannelSelect(nn.Module):
    def __init__(self, start: int, end: int):
        super().__init__()
        self.start = int(start)
        self.end = int(end)

    def forward(self, x):
        return x[:, self.start:self.end, :, :]


class AlignWarp(nn.Module):
    def __init__(
        self,
        c_sp: int,
        c_opt: int,
        hidden: int = 16,
        max_shift: float = 1.0,
        visualize_freq: int = 10,
        save_dir: str = "./visualizations",
        reg_weight: float = 0.01,
        curriculum_epochs: int = 0,
        curriculum_max_shift: float = 5.0,
    ):
        super().__init__()
        self.c_sp = int(c_sp)
        self.c_opt = int(c_opt)
        self.hidden = int(hidden)
        self.max_shift = float(max_shift)
        self.visualize_freq = int(visualize_freq)
        self.save_dir = str(save_dir) if isinstance(save_dir, str) else "./visualizations"
        self.reg_weight = float(reg_weight)
        self.curriculum_epochs = int(curriculum_epochs)
        self.curriculum_max_shift = float(curriculum_max_shift)

        try:
            os.makedirs(self.save_dir, exist_ok=True)
        except Exception:
            pass

        self.offnet = nn.Sequential(
            Conv(self.c_sp + self.c_opt, self.hidden, k=3, s=1),
            Conv(self.hidden, self.hidden, k=3, s=1),
            nn.Conv2d(self.hidden, 2, kernel_size=1, stride=1, padding=0),
        )
        nn.init.zeros_(self.offnet[-1].weight)
        nn.init.zeros_(self.offnet[-1].bias)

        self._grid_cache: dict[tuple, torch.Tensor] = {}
        self._meta: dict = {}
        self.aux_loss_container = []
        self.l1_loss = nn.L1Loss()

        try:
            g = torch.tensor(
                [[1 / 16, 2 / 16, 1 / 16], [2 / 16, 4 / 16, 2 / 16], [1 / 16, 2 / 16, 1 / 16]],
                dtype=torch.float32,
            )
            self.register_buffer("gaussian_3x3", g.view(1, 1, 3, 3), persistent=False)
        except Exception:
            self.gaussian_3x3 = None

    def set_meta(self, **kwargs):
        self._meta.update(kwargs)
        return self

    def __getstate__(self):
        state = self.__dict__.copy()
        state["_grid_cache"] = {}
        state["_meta"] = {}
        state["aux_loss_container"] = []
        return state

    def _base_grid(self, H: int, W: int, device, dtype):
        key = (H, W, str(device), str(dtype))
        g = self._grid_cache.get(key, None)
        if g is not None and g.device == device and g.dtype == dtype:
            return g
        ys = torch.linspace(-1, 1, H, device=device, dtype=dtype)
        xs = torch.linspace(-1, 1, W, device=device, dtype=dtype)
        grid_y, grid_x = torch.meshgrid(ys, xs, indexing="ij")
        grid = torch.stack([grid_x, grid_y], dim=-1).unsqueeze(0)
        self._grid_cache[key] = grid
        return grid

    def forward(self, x, **kwargs):
        F_sp, F_opt = x
        B, _, H, W = F_sp.shape

        epoch = self._meta.get("epoch", None)
        dtype = next(self.offnet.parameters()).dtype
        F_sp = F_sp.to(dtype)
        F_opt = F_opt.to(dtype)

        if self.gaussian_3x3 is not None:
            Csp = F_sp.shape[1]
            kernel = self.gaussian_3x3.to(device=F_sp.device, dtype=F_sp.dtype).repeat(Csp, 1, 1, 1)
            F_sp_enhanced = F.conv2d(F_sp, kernel, padding=1, groups=Csp)
        else:
            F_sp_enhanced = F_sp

        local_mean = F.avg_pool2d(F_sp_enhanced, kernel_size=3, stride=1, padding=1)
        F_sp_peaks = F.relu(F_sp_enhanced - local_mean)

        flow = self.offnet(torch.cat([F_sp_peaks, F_opt], dim=1))

        eff_max_shift = self.max_shift
        if (epoch is not None) and (self.curriculum_epochs > 0) and (epoch < self.curriculum_epochs):
            t = float(epoch) / float(max(self.curriculum_epochs, 1))
            eff_max_shift = self.curriculum_max_shift + t * (self.max_shift - self.curriculum_max_shift)

        flow = torch.tanh(flow) * float(eff_max_shift)

        denom_x = max((W - 1) / 2.0, 1.0)
        denom_y = max((H - 1) / 2.0, 1.0)
        dx = flow[:, 0] / denom_x
        dy = flow[:, 1] / denom_y
        flow_norm = torch.stack([dx, dy], dim=-1)

        base = self._base_grid(H, W, F_sp.device, F_sp.dtype)
        grid = base + flow_norm

        F_sp_aligned = F.grid_sample(F_sp, grid, mode="bilinear", padding_mode="border", align_corners=True)

        loss_mag = (flow ** 2).mean()
        loss_smooth = (flow[:, :, 1:] - flow[:, :, :-1]).abs().mean() + (flow[:, :, :, 1:] - flow[:, :, :, :-1]).abs().mean()
        alignment_loss = loss_mag * float(self.reg_weight) + loss_smooth * 0.1
        self.aux_loss_container = [alignment_loss if alignment_loss.requires_grad else alignment_loss.detach()]

        return F_sp_aligned


class CMGA_Guidance(nn.Module):
    def __init__(
        self,
        c_sp: int,
        c_opt: int,
        hidden: int = 16,
        temp: float = 2.0,
        stop_gradient: bool = False,
        beta_init: float = -2.0,
    ):
        super().__init__()
        self.temp = float(temp)
        self.stop_gradient = bool(stop_gradient)

        self.sp_enhancer = nn.Sequential(
            Conv(int(c_sp), int(hidden), k=3, s=1),
            Conv(int(hidden), int(hidden), k=3, s=1),
        )
        self.sp_to_attn = nn.Sequential(
            Conv(int(hidden), int(hidden), k=3, s=1),
            nn.Conv2d(int(hidden), 1, kernel_size=1, stride=1, padding=0),
        )
        self.beta = nn.Parameter(torch.tensor(float(beta_init)))
        self.opt_align = nn.Identity()

    def forward(self, x, **kwargs):
        if not isinstance(x, (list, tuple)) or len(x) != 2:
            raise TypeError(f"CMGA_Guidance expected [F_sp, F_opt], got {type(x)}")
        F_sp, F_opt = x

        dtype = next(self.sp_enhancer.parameters()).dtype
        F_sp = F_sp.to(dtype)
        F_opt = F_opt.to(dtype)
        F_opt = self.opt_align(F_opt)

        F_sp_enhanced = self.sp_enhancer(F_sp.detach() if self.stop_gradient else F_sp)
        A = self.sp_to_attn(F_sp_enhanced)
        A = torch.sigmoid(A / float(self.temp))

        beta = torch.sigmoid(self.beta)
        output = F_opt + beta * (A * F_opt)

        visualize_dir = kwargs.get("visualize", False)
        if visualize_dir:
            save_dir = Path("runs/detect/exp") if isinstance(visualize_dir, bool) else Path(str(visualize_dir))
            stage = int(kwargs.get("stage", -1))
            module_type = kwargs.get("module_type", self.__class__.__name__)
            n = int(kwargs.get("vis_n", 32))
            feature_visualization(F_opt, f"{module_type}_pre", stage, n=n, save_dir=save_dir)
            feature_visualization(output, f"{module_type}_post", stage, n=n, save_dir=save_dir)

        return output


class SSENhance(nn.Module):
    def __init__(self, c_sp: int, c_opt: int, hidden: int = 32, reduction: int = 16):
        super().__init__()
        self.sp_align = Conv(int(c_sp), int(c_opt), k=1, s=1) if int(c_sp) != int(c_opt) else nn.Identity()
        self.sp_enhancer = nn.Sequential(
            Conv(int(c_opt), int(c_opt), k=3, s=1),
            Conv(int(c_opt), int(c_opt), k=3, s=1),
        )
        self.opt_enhancer = nn.Sequential(
            Conv(int(c_opt), int(c_opt), k=3, s=1),
            Conv(int(c_opt), int(c_opt), k=3, s=1),
        )

        red = max(int(c_opt) // int(reduction), 1)
        self.sp_to_opt_channel_attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(int(c_opt), red, kernel_size=1, stride=1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(red, int(c_opt), kernel_size=1, stride=1, padding=0),
            nn.Sigmoid(),
        )
        self.opt_to_sp_channel_attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(int(c_opt), red, kernel_size=1, stride=1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(red, int(c_opt), kernel_size=1, stride=1, padding=0),
            nn.Sigmoid(),
        )
        self.joint_spatial_attn = nn.Sequential(
            nn.Conv2d(int(c_opt) * 2, int(c_opt), kernel_size=1, stride=1, padding=0),
            nn.Sigmoid(),
        )
        self.fusion_conv = Conv(int(c_opt) * 2, int(c_opt), k=1, s=1)
        self.fusion_weight = nn.Parameter(torch.tensor(0.0))

    def forward(self, x, **kwargs):
        if not isinstance(x, (list, tuple)) or len(x) != 2:
            raise TypeError(f"SSENhance expected [F_sp, F_opt], got {type(x)}")
        F_sp, F_opt = x

        dtype = next(self.fusion_conv.parameters()).dtype
        F_sp = F_sp.to(dtype)
        F_opt = F_opt.to(dtype)

        F_sp_aligned = self.sp_align(F_sp)
        F_sp_enhanced = self.sp_enhancer(F_sp_aligned)
        F_opt_enhanced = self.opt_enhancer(F_opt)

        sp_ca = self.sp_to_opt_channel_attn(F_sp_enhanced)
        opt_ca = self.opt_to_sp_channel_attn(F_opt_enhanced)
        F_opt_attended = F_opt_enhanced * sp_ca
        F_sp_attended = F_sp_enhanced * opt_ca

        spatial_attn = self.joint_spatial_attn(torch.cat([F_opt_attended, F_sp_attended], dim=1))
        F_opt_spatial = F_opt_attended * spatial_attn
        F_sp_spatial = F_sp_attended * spatial_attn

        fused = torch.cat([F_opt_spatial, F_sp_spatial], dim=1)
        fused_output = self.fusion_conv(fused)
        fusion_weight = torch.sigmoid(self.fusion_weight)
        output = F_opt_enhanced + fusion_weight * fused_output

        return output
